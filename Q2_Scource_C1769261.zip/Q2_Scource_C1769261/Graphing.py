	
import csv
from numpy import random as r
import numpy as np
from random import randint
import matplotlib.pyplot as plt
from collections import Counter

def graph_score(scores):
	print('Link Start')
	growing_average = {'Alice':0,'Bob':0,'Clare':0,'Dennis':0,'Eva':0}
	sailor_x = {'Alice':[],'Bob':[],'Clare':[],'Dennis':[],'Eva':[]}
	sailor_y = {'Alice':[],'Bob':[],'Clare':[],'Dennis':[],'Eva':[]}
	sums = 0
	for group in scores:
		sums += 1
		for sailors in group:
			growing_average[sailors] += group[sailors]
		for sailor in growing_average:
			sailor_y[sailor].append(growing_average[sailor] / sums)
			sailor_x[sailor].append(sums)
	for sailor in sailor_x:
		plt.plot(sailor_x[sailor], sailor_y[sailor], label=str(sailor))
	plt.legend(loc='upper right')
	plt.xscale('log')
	plt.title('Performace')
	plt.xlabel('Races run')
	plt.ylabel('Average Score every race')
	plt.show()

def plot_bell():
	race_standing = (generate_performances(read_sailor_data('RobotSailors')))
	sailors = read_sailor_data()
	x = []; y=[];
	standing_count = sorted(gen_counts(race_standing))

	for items in standing_count:
		x.append(items[0])
		y.append(items[1])

	plt.plot(x, y,'ro')
	#plt.legend()
	plt.title('Performace')
	plt.xlabel('Score')
	plt.ylabel('Amount of people that got the Race Score')
	plt.axis([min(x), max(x)*1.1, min(y), max(y)*1.1])
	plt.show()

def gen_counts(race_standing):
	count = []
	count_output = []
	for s in race_standing:
		count.append(int(race_standing[s]))
	data = (Counter(count))
	data[0] = data[0]/2
	for numbers in data:
		count_output.append([numbers,data[numbers]])
	return count_output

def add_sailor_for_graph(loops,choice):
	print(choice)
	with open('RobotSailors.csv', mode='w', newline='') as f:
		writer = csv.writer(f)
		if choice == 'low':
			s = randint(30,60)
			v = 20
		elif choice == 'high':
			s = randint(45,75)
			v = 10
		for i in range(loops):
			writer.writerow(['Example'+str(i), s, v])  #This is for medium Varience and a consistantly high skill


def importing_csv_file(filename):		#This takes the filename of the csv file as input so it knows where to collect the data from.
	with open(filename+'.csv') as f:
		reader = csv.reader(f)			#Then it opens the file and begines to read the data from it.
		raw_data = [r for r in reader]
	return raw_data[1:]					#It then returns the raw data of the file minus the header.

def read_sailor_data(filename = 'sailor_performances for Graphing'):								
	raw_data = importing_csv_file(filename)
	sailors = {}
	for people in raw_data:										
		sailors.update({people[0]:(float(people[1]),float(people[2]))})	#This iterated through all the lines on the raw data from the csv file and then
	return(sailors)														#it simultaneously converts the data into the dictionary format.

def generate_performances(sailors):
	scores = {}
	for person in sailors:										#This code will iterate through the sailors and then 
		score = r.normal(sailors[person][0],sailors[person][1])	#using the numpy library random distribution method will
		scores.update({person : score})							# assign each of the sailors a score and then update a dictionary with these scores.
	return scores

def calculate_finishing_order(sailor_scores):
	win_order = []
	for people in (sorted(sailor_scores.items(), key = lambda x: x[1],reverse=True)):	#This line sorts the people in the sailor scores parameter and then also begins
		win_order.append(people[0])											#a loop with them which allows it to have the win order so to print the winers
	return win_order, sailor_scores														#it can just run through the loop. Instead it adds them in order to a winning order array

def simulate_the_races(races=6):
	results = {}
	allScores = []
	for sailor in read_sailor_data():												#This iterates through the sailors in the csv file
		results.update({sailor:[]})													#it initializes a new results dictionary for the silors in the csv file
	for i in range(races):													
		win_order,scores = (calculate_finishing_order(generate_performances(read_sailor_data())))	#Then it runs a loop that for however many times the user want to run the races for
		allScores.append(scores)
		for person in win_order:															#after it generates the perfromances and works out hte finishing order it will show the winners
			results[person].append(win_order.index(person)+1)
	return results, win_order, allScores


def main():

	print('Sailing Race Simulator')
	while True:
		print('For a graph showing the effects of Varience over time enter: V')
		print('For a Bell graph enter: B')
		print('Or to exit enter: X')
		u = str(input('>> ')).upper()
		if u == 'B':
			roboSailors = int(input('How many sailors would you like to see ? (100000 recommended)\n>> '))
			choice =  int(input('Would you like graph 1 or graph 2 form the report? (1/2)\n>> '))
			if choice == 1:
				mode = 'high'
			else:
				mode = 'low'
			add_sailor_for_graph(10000,mode)
			plot_bell()
		if u == 'V':
			loops = int(input('How many races would you like to run 5000 recommended (takes about 30 seconds)\n>> '))
			results, standing, scores= simulate_the_races(loops)	
			graph_score(scores)
		if u == 'X':
			exit()
		else:	
			print('Invalid')

if __name__ == '__main__':
	main()					#runs on start.
	